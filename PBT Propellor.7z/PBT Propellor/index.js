function myFunction() {
    document.getElementsByClassName("centralNav")[0].classList.toggle("responsive");
}