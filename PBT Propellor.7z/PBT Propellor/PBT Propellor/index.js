function myFunction() {
    document.getElementsByClassName("centralNav")[0].classList.toggle("responsive");
}

function mouseOverPanel1() {
    $(".panel-desc1").css("visibility", "visible");
    $(".grid-item1").css("opacity", "0.7");
}

function mouseOutPanel1() {
    $(".panel-desc1").css("visibility", "hidden");
}

function mouseOverPanel2() {
    $(".panel-desc2").css("visibility", "visible");
    $(".grid-item2").css("opacity", "0.7");
}

function mouseOutPanel2() {
    $(".panel-desc2").css("visibility", "hidden");
}

function mouseOverPanel3() {
    $(".panel-desc3").css("visibility", "visible");
    $(".grid-item3").css("opacity", "0.7");
}

function mouseOutPanel3() {
    $(".panel-desc3").css("visibility", "hidden");
}

function mouseOverPanel4() {
    $(".panel-desc4").css("visibility", "visible");
    $(".grid-item4").css("opacity", "0.7");
}

function mouseOutPanel4() {
    $(".panel-desc4").css("visibility", "hidden");
}